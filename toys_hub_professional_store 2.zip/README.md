# ToyHub — real ecommerce starter

This version upgrades the static demo into a working Node/Express ecommerce starter with:

- Product catalogue
- Search and category filter
- Shopping cart
- Customer + delivery form
- Server-side Paystack transaction initialization
- Paystack redirect checkout
- Server-side transaction verification
- Basic order storage
- Simple admin order viewer at `/admin.html`

## Important

The project is configured for **Paystack Test Mode** first. Do not put a Paystack secret key in browser JavaScript. The secret key stays in `.env` on the server.

## Run on a computer

1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Add your Paystack **test secret key**:
   `PAYSTACK_SECRET_KEY=sk_test_...`
4. Set:
   `STORE_URL=http://localhost:3000`
5. Choose a strong `ADMIN_KEY`.
6. Run:
   `npm install`
   `npm start`
7. Open:
   `http://localhost:3000`

## Paystack

Use your Paystack dashboard to get test keys first. Test the complete flow before switching to live keys.

For production:
- change `PAYSTACK_SECRET_KEY` to your live secret key
- set `STORE_URL` to your HTTPS domain
- use a strong admin key
- replace the JSON order storage with a real database
- add webhook handling
- add proper admin authentication
- add real product images and inventory management
- add shipping rules and customer notifications

## Admin

Open:
`/admin.html`

Enter the `ADMIN_KEY` from `.env`.

## Customize products

Edit the `products` array in `server.js`.

For a full production store, I recommend moving products/orders to PostgreSQL or Supabase rather than keeping orders in a JSON file.


## Current Toys Hub configuration

- Store name: **Toys Hub**
- Domain requested: **www.toyhubs.com**
- Product focus: kids racing cars, trucks, supercars, bikes, planes and collectibles
- Categories: **Cars, Trucks, Supercars, Bikes, Planes**
- Delivery fee: **$30.00**
- Currency for this starter checkout: **USD**

The requested list contains five categories, so the store uses all five: Cars, Trucks, Supercars, Bikes and Planes.

### Domain

The code is ready to use with `www.toyhubs.com`, but owning/connecting the domain still requires registering the domain and configuring DNS/hosting. A domain name cannot be made live by changing code alone.

### Important Paystack currency note

This version labels the checkout as USD because you requested a $30 delivery fee. Paystack availability of a particular currency depends on the merchant/account setup, so confirm the currency your Paystack account supports before going live. Paystack's API requires the amount in the currency's subunit and the server should verify the payment amount before fulfilling an order.


The frontend has been upgraded with a polished Toys Hub storefront, hero banner, category tiles, trust/service highlights, responsive product cards and branded footer.
