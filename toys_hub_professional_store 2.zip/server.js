const express = require("express");
const path = require("path");
const fs = require("fs");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const ORDERS_FILE = path.join(DATA_DIR, "orders.json");

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, "[]");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const products = [
  { id: 1, name: "Kids Racing Car", price: 14990, category: "Cars", emoji: "🏎️", stock: 25 },
  { id: 2, name: "Remote Control Race Car", price: 22990, category: "Cars", emoji: "🚗", stock: 18 },
  { id: 3, name: "Monster Truck Toy", price: 18990, category: "Trucks", emoji: "🚚", stock: 20 },
  { id: 4, name: "Off-Road RC Truck", price: 26990, category: "Trucks", emoji: "🛻", stock: 14 },
  { id: 5, name: "Luxury Supercar Collectible", price: 24990, category: "Supercars", emoji: "🏎️", stock: 16 },
  { id: 6, name: "Supercar Die-Cast Collection", price: 19990, category: "Supercars", emoji: "🚘", stock: 22 },
  { id: 7, name: "Kids Racing Bike", price: 16990, category: "Bikes", emoji: "🏍️", stock: 15 },
  { id: 8, name: "Mini Motorcycle Collectible", price: 12990, category: "Bikes", emoji: "🏍️", stock: 24 },
  { id: 9, name: "Passenger Plane Toy", price: 17990, category: "Planes", emoji: "✈️", stock: 17 },
  { id: 10, name: "Jet Fighter Collectible", price: 21990, category: "Planes", emoji: "🛩️", stock: 12 },
  { id: 11, name: "Airport Playset", price: 29990, category: "Planes", emoji: "🛫", stock: 9 },
  { id: 12, name: "Classic Car Collectible", price: 15990, category: "Cars", emoji: "🚙", stock: 21 }
];

function readOrders() {
  return JSON.parse(fs.readFileSync(ORDERS_FILE, "utf8"));
}
function writeOrders(orders) {
  fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2));
}
function makeReference() {
  return `TH-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

app.get("/api/products", (req, res) => res.json(products));

app.post("/api/paystack/initialize", async (req, res) => {
  try {
    if (!process.env.PAYSTACK_SECRET_KEY) {
      return res.status(500).json({ error: "PAYSTACK_SECRET_KEY is not configured." });
    }

    const { email, customer, items, address, phone } = req.body;
    if (!email || !customer || !phone || !address || !Array.isArray(items) || !items.length) {
      return res.status(400).json({ error: "Please provide customer details and at least one product." });
    }

    // Recalculate the total on the server. Never trust the amount sent by the browser.
    const DELIVERY_FEE = 30;
    let subtotal = 0;
    const cleanItems = [];
    for (const item of items) {
      const product = products.find(p => p.id === Number(item.id));
      const qty = Math.max(1, Math.min(20, Number(item.qty) || 1));
      if (!product) continue;
      if (qty > product.stock) {
        return res.status(400).json({ error: `${product.name} does not have enough stock.` });
      }
      subtotal += product.price * qty;
      cleanItems.push({ id: product.id, name: product.name, price: product.price, qty });
    }

    if (!cleanItems.length) return res.status(400).json({ error: "No valid products in cart." });

    const reference = makeReference();
    const order = {
      reference,
      email,
      customer,
      phone,
      address,
      items: cleanItems,
      subtotal,
      deliveryFee: DELIVERY_FEE,
      amount: subtotal + DELIVERY_FEE,
      currency: "USD",
      status: "pending",
      createdAt: new Date().toISOString()
    };

    const response = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        email,
        amount: (subtotal + DELIVERY_FEE) * 100,
        currency: "NGN",
        reference,
        callback_url: `${process.env.STORE_URL || `http://localhost:${PORT}`}/payment-success.html`,
        metadata: {
          reference,
          customer,
          phone,
          address,
          items: cleanItems
        }
      })
    });

    const data = await response.json();
    if (!response.ok || !data.status) {
      return res.status(502).json({ error: data.message || "Paystack initialization failed." });
    }

    order.authorization_url = data.data.authorization_url;
    order.access_code = data.data.access_code;
    writeOrders([...readOrders(), order]);

    res.json({ authorization_url: data.data.authorization_url, reference });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not start payment." });
  }
});

app.get("/api/paystack/verify/:reference", async (req, res) => {
  try {
    if (!process.env.PAYSTACK_SECRET_KEY) {
      return res.status(500).json({ error: "PAYSTACK_SECRET_KEY is not configured." });
    }

    const response = await fetch(
      `https://api.paystack.co/transaction/verify/${encodeURIComponent(req.params.reference)}`,
      { headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}` } }
    );
    const data = await response.json();

    if (!response.ok || !data.status) {
      return res.status(400).json({ error: data.message || "Verification failed." });
    }

    const tx = data.data;
    const orders = readOrders();
    const index = orders.findIndex(o => o.reference === req.params.reference);

    if (index >= 0) {
      // Only mark paid if Paystack says successful AND the paid amount matches our order.
      const expectedSubunit = orders[index].amount * 100;
      if (tx.status === "success" && Number(tx.amount) === expectedSubunit) {
        orders[index].status = "paid";
        orders[index].paidAt = new Date().toISOString();
        writeOrders(orders);
      }
    }

    res.json({
      status: tx.status,
      reference: tx.reference,
      amount: tx.amount,
      currency: tx.currency
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not verify payment." });
  }
});

app.get("/api/admin/orders", (req, res) => {
  if (!process.env.ADMIN_KEY || req.headers["x-admin-key"] !== process.env.ADMIN_KEY) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  res.json(readOrders().reverse());
});

app.get("/api/health", (req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`ToyHub running on http://localhost:${PORT}`);
});
